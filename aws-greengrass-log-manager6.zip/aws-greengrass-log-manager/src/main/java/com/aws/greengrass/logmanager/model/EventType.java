package com.aws.greengrass.logmanager.model;

public enum EventType {
    ALL_COMPONENTS_PROCESSED
}
